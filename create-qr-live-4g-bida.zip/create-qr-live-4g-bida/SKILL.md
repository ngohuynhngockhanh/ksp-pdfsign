---
name: create-qr-live-4g-bida
description: "Prepare or create public livestream QR nodes for 4G billiards camera sites, using the iNut API and guarded SSH discovery."
---

# Create QR Live 4G Bida

Use this skill when the user wants QR codes that open public livestream channels for a billiards/4G camera site.

## Known Surface

- Central CLI: `/app/STRAPI_API_TERMINAL/strapi_cli.sh` on `root@77.87.50.96`.
- CLI config: `/app/STRAPI_API_TERMINAL/config.ini`; never print `STRAPI_API_KEY` or other secret values.
- Typical device route: `root@172.16.5.180` -> `root@<device-overlay-ip>` (for example `77.88.204.221`).
- A physical device root can be `type=sbroadcast`, with an API node id and an MQTT id such as `cast204.221`.

## Workflow

1. Start read-only. Resolve the physical target, API root node id, label, MQTT id, camera count, active stream directories, and existing child nodes.
2. Do not run the legacy CLI unchanged when the physical MQTT id lacks `camera01`. The legacy script only accepts a root containing `camera01` and clones livestream metadata; physical `cast...` roots commonly lack `public_info`.
3. Before any write, propose the namespace and metadata mapping. Prefer the established form `livestream_<slug>.camera01` ... `cameraNN`; derive the public HLS host/path and `public_info` from a verified sibling livestream site, never by guessing or copying credentials.
4. Ask the user for explicit approval immediately before API `POST` or device-side changes. API node ids are server-generated; never assign ids manually.
5. Create idempotently: GET/check each MQTT id first, POST only missing nodes, and preserve the proven livestream fields while changing only the site slug, camera suffix, label, and public URL suffix as appropriate.
6. Generate each QR payload as `{"shop_id": <node-id>}` and package PNGs as `qrcode_<root-id>_<label>.zip`. Report the node-id-to-camera mapping and artifact path without exposing tokens, passwords, or private camera URLs.
7. Verify after approval: re-read all created nodes, check QR file count and ZIP integrity, and test a small sample of public HLS URLs. Do not restart PM2, Shinobi, or camera services unless separately requested.

## Safety and Handoff

- Treat SSH/API access as authorized only for the named hosts and site; keep discovery narrow and reversible.
- Never log or paste API keys, MQTT credentials, camera passwords, private RTSP URLs, or full secret-bearing `public_info` values.
- If the public relay mapping, camera count, or target route is ambiguous, stop after the plan and ask for the missing decision.
- When asked to package the skill, place the ZIP under `~/ksp-pdfsign` only after checking its public-serving mechanism; do not claim a public URL unless an HTTP endpoint is verified.
